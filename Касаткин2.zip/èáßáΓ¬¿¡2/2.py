from typing import List


class Services:
    def __init__(self, name, price, fiom, datao, tocalculation):
        self.name = name
        self.price = price
        self.fiom = fiom
        self.datao = datao
        self.tocalculation = tocalculation


class Clients:
    def __init__(self, fiok, phone, discount, servicereceived):
        self.fiok = fiok
        self.phone = phone
        self.discount = discount
        self.servicereceived = servicereceived

        # Добавляем клиента
        def append(self, clients: Clients):
            self.clients.append(clients)
            self.clients_num = len(self.clients)

        # Удаляем абонента
        def remove(self, clients: Clients):
            try:
                self.clients.remove(clients)
            except:
                return False
            else:
                self.clients_num = len(self.clients)
                return True

        # Инф-я о Клиенте
        def __str__(self):
            return f"ФИО клиента: {self.fiok}, Телефон: {self.phone}, Скидка: {self.discount}, Полученные услуги: {self.servicereceived} "

        # Вывести данные об абонентах указанного тарифа
        def print_discount(self):
            for discount in self.discount:
                print(discount)

    # Сравнение клиентов по размеру скидки, услуг по стоимости
    def __lt__(self, other):  # <
        return self.discount < other.discount

    def __gt__(self, other):  # >
        return self.discount > other.discount

    def __eq__(self, other):  # ==
        res = self.discount == other.discount
        if res:
            return self.servicereceived == other.servicereceived
        return res

    def __le__(self, other):  # <=
        if self.__eq__(other):
            return True

    def __ge__(self, other):  # >=
        if self.__eq__(other):
            return True


Clients1 = Clients('Гришкавец Сергей Николаевич', '784793758', 100, 'стрижка')
Clients2 = Clients('Кочеткова Елизавета Петровна', '740839583', 20, 'окрашивание')
Clients3 = Clients('Семенова Елизавета Игоревна', '178357938', 0, 'стрижка')
Client4 = Clients('Лукьянов Лука Глебович', '1234567890', 36000)

discount1 = Clients = Clients('стрижка', 100, 20, True, False, [Clients1, Clients2])
discount2 = Clients('окрашивание', 0, True, False, [Clients3])

discount = Clients([discount1, discount2])

print("2 - Сравнение клиентов по размеру скидки")
print(discount1 < discount2)
print(discount1 > discount2)
print(discount1 == discount2)
print(discount1 <= discount2)
print(discount1 >= discount2)
print()
